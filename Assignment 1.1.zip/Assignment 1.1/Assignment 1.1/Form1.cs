﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_1._1
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            // Error handling to make sure a number between 1 and 10000 is entered.
            // also assigns the number entered to the size varable and passes it out.
            // also sets the limits 
            if (!int.TryParse(txtNumber.Text, out int size) || size < 1 || size > 10000)
            {

                // Message if a number in range is not entered.
                MessageBox.Show("Please enter a valid number between 1 - 10,000.");
                return;
            }

            //passes size into the array varable.
            int[] array = new int[size];
            // assigns a random number to the random varable.
            Random random = new Random();


            // Creates and starts a timer.
            Stopwatch genTimer = new Stopwatch();
            genTimer.Start();

            // creates the array 
            for (int i = 0; i < size; i++)
            {
                // for each i it enters a random number between 1-10000.
                array[i] = random.Next(1, 10001);
            }

            // Stops the timer
            genTimer.Stop();

            // creates a new timer for the sorting
            Stopwatch sortTimer = new Stopwatch();
            sortTimer.Start();
            // sorts the array.
            Array.Sort(array);
            sortTimer.Stop();

            // assigns the timer value to each label.  TotalMilliseconds is a double so it is converted to a string.
            // TotalMilliseconds is used to get factions of a millisecond instead ElapsedMilliseconds which rounds.
            lblGenTime.Text = genTimer.Elapsed.TotalMilliseconds.ToString() + " ms";
            lblSortTime.Text = sortTimer.Elapsed.TotalMilliseconds.ToString() + " ms";

        }
    }
}
