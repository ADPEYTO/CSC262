﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fakagachi_V3
{
    class Cat : VirtualPet
    {
        // Cat class inherits from VirtualPet
        public string Breed { get; set; }
        public string Size { get; set; }

        // Constructor for Cat class
        public Cat(string name, string species, string color, string gender, int hunger, int happiness, int energy, int age, bool isAlive, string breed, string size)
            : base(name, species, color, gender, hunger, happiness, energy, age, isAlive)
        {
            Breed = breed;
            Size = size;
        }

        // Display method for Cat class
        public override string Display()
        {
            return base.Display();
        }

        // Overriding the Display method to show different attributes based on the number passed
        // This method is used to display the pet's information based on the number passed
        public override string Display(int num)
        {

            if (num == 1)
            {
                return Name;
            }
            else if (num == 2)
            {
                return Name + " " + Species;
            }
            else if (num == 3)
            {
                return Name + " " + Species + " " + Color;
            }
            else if (num == 4)
            {
                return Name + " " + Species + " " + Color + " " + Gender;
            }
            else if (num == 5)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger;
            }
            else if (num == 6)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness;
            }
            else if (num == 7)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy;
            }
            else if (num == 8)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy + " " + Age;
            }
            else if (num == 9)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy + " " + Age + " " + IsAlive;
            }
            else if (num == 10)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy + " " + Age + " " + IsAlive + " " + Breed;
            }
            else if (num == 11)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy + " " + Age + " " + IsAlive + " " + Breed + " " + Size;
            }
            else
            {
                return Name;
            }

        }
    }
}
