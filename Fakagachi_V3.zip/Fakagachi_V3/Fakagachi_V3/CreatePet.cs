﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fakagachi_V3
{
    class CreatePet
    {
        public static VirtualPet Create(
            string name,
            string species,
            string color,
            string gender,
            string breed,
            string size)
        {
            // Use default stats or generate randomly if needed
            int hunger = 50;
            int happiness = 50;
            int energy = 50;
            int age = 0;
            bool isAlive = true;

            switch (species)
            {
                case "Dog":
                    return new Dog(name, species, color, gender, hunger, happiness, energy, age, isAlive, breed, size);
                case "Cat":
                    return new Cat(name, species, color, gender, hunger, happiness, energy, age, isAlive, breed, size);
                case "Bird":
                    return new Bird(name, species, color, gender, hunger, happiness, energy, age, isAlive, breed, size);
                case "Reptile":
                    return new Reptile(name, species, color, gender, hunger, happiness, energy, age, isAlive, breed, size);
                default:
                    return new VirtualPet(name, species, color, gender, hunger, happiness, energy, age, isAlive);
            }
        }
    }
}
