﻿namespace Fakagachi_V3
{
    partial class form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtPetName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbSpecies = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPetColor = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbGender = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblHunger = new System.Windows.Forms.Label();
            this.lblHappiness = new System.Windows.Forms.Label();
            this.lblEnergy = new System.Windows.Forms.Label();
            this.pbHunger = new System.Windows.Forms.ProgressBar();
            this.pbHappiness = new System.Windows.Forms.ProgressBar();
            this.pbEnergy = new System.Windows.Forms.ProgressBar();
            this.label8 = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.btnFeed = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnSleep = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.cbBreed = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbSize = new System.Windows.Forms.ComboBox();
            this.btnCreatePet = new System.Windows.Forms.Button();
            this.btnSaveAndExit = new System.Windows.Forms.Button();
            this.lbDisplay = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pets Name";
            // 
            // txtPetName
            // 
            this.txtPetName.Location = new System.Drawing.Point(18, 40);
            this.txtPetName.Name = "txtPetName";
            this.txtPetName.Size = new System.Drawing.Size(100, 22);
            this.txtPetName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Species";
            // 
            // cbSpecies
            // 
            this.cbSpecies.FormattingEnabled = true;
            this.cbSpecies.Location = new System.Drawing.Point(18, 189);
            this.cbSpecies.Name = "cbSpecies";
            this.cbSpecies.Size = new System.Drawing.Size(121, 24);
            this.cbSpecies.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Color";
            // 
            // txtPetColor
            // 
            this.txtPetColor.Location = new System.Drawing.Point(18, 85);
            this.txtPetColor.Name = "txtPetColor";
            this.txtPetColor.Size = new System.Drawing.Size(100, 22);
            this.txtPetColor.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Gender";
            // 
            // cbGender
            // 
            this.cbGender.FormattingEnabled = true;
            this.cbGender.Location = new System.Drawing.Point(18, 137);
            this.cbGender.Name = "cbGender";
            this.cbGender.Size = new System.Drawing.Size(121, 24);
            this.cbGender.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(223, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Hunger";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(223, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 16);
            this.label6.TabIndex = 9;
            this.label6.Text = "Happiness";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(223, 147);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Energy";
            // 
            // lblHunger
            // 
            this.lblHunger.AutoSize = true;
            this.lblHunger.Location = new System.Drawing.Point(223, 56);
            this.lblHunger.Name = "lblHunger";
            this.lblHunger.Size = new System.Drawing.Size(28, 16);
            this.lblHunger.TabIndex = 11;
            this.lblHunger.Text = "100";
            // 
            // lblHappiness
            // 
            this.lblHappiness.AutoSize = true;
            this.lblHappiness.Location = new System.Drawing.Point(223, 112);
            this.lblHappiness.Name = "lblHappiness";
            this.lblHappiness.Size = new System.Drawing.Size(28, 16);
            this.lblHappiness.TabIndex = 12;
            this.lblHappiness.Text = "100";
            // 
            // lblEnergy
            // 
            this.lblEnergy.AutoSize = true;
            this.lblEnergy.Location = new System.Drawing.Point(223, 172);
            this.lblEnergy.Name = "lblEnergy";
            this.lblEnergy.Size = new System.Drawing.Size(28, 16);
            this.lblEnergy.TabIndex = 13;
            this.lblEnergy.Text = "100";
            // 
            // pbHunger
            // 
            this.pbHunger.Location = new System.Drawing.Point(312, 49);
            this.pbHunger.Name = "pbHunger";
            this.pbHunger.Size = new System.Drawing.Size(148, 23);
            this.pbHunger.TabIndex = 14;
            // 
            // pbHappiness
            // 
            this.pbHappiness.Location = new System.Drawing.Point(312, 104);
            this.pbHappiness.Name = "pbHappiness";
            this.pbHappiness.Size = new System.Drawing.Size(148, 23);
            this.pbHappiness.TabIndex = 15;
            // 
            // pbEnergy
            // 
            this.pbEnergy.Location = new System.Drawing.Point(312, 165);
            this.pbEnergy.Name = "pbEnergy";
            this.pbEnergy.Size = new System.Drawing.Size(148, 23);
            this.pbEnergy.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(223, 208);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "Age";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(223, 235);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(14, 16);
            this.lblAge.TabIndex = 18;
            this.lblAge.Text = "0";
            // 
            // btnFeed
            // 
            this.btnFeed.Location = new System.Drawing.Point(44, 447);
            this.btnFeed.Name = "btnFeed";
            this.btnFeed.Size = new System.Drawing.Size(75, 39);
            this.btnFeed.TabIndex = 19;
            this.btnFeed.Text = "Feed";
            this.btnFeed.UseVisualStyleBackColor = true;
            this.btnFeed.Click += new System.EventHandler(this.btnFeed_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(199, 448);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 38);
            this.btnPlay.TabIndex = 20;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnSleep
            // 
            this.btnSleep.Location = new System.Drawing.Point(364, 448);
            this.btnSleep.Name = "btnSleep";
            this.btnSleep.Size = new System.Drawing.Size(75, 38);
            this.btnSleep.TabIndex = 21;
            this.btnSleep.Text = "Sleep";
            this.btnSleep.UseVisualStyleBackColor = true;
            this.btnSleep.Click += new System.EventHandler(this.btnSleep_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 225);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 16);
            this.label10.TabIndex = 22;
            this.label10.Text = "Breed";
            // 
            // cbBreed
            // 
            this.cbBreed.FormattingEnabled = true;
            this.cbBreed.Location = new System.Drawing.Point(18, 244);
            this.cbBreed.Name = "cbBreed";
            this.cbBreed.Size = new System.Drawing.Size(121, 24);
            this.cbBreed.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 280);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 16);
            this.label11.TabIndex = 24;
            this.label11.Text = "Size";
            // 
            // cbSize
            // 
            this.cbSize.FormattingEnabled = true;
            this.cbSize.Location = new System.Drawing.Point(18, 299);
            this.cbSize.Name = "cbSize";
            this.cbSize.Size = new System.Drawing.Size(121, 24);
            this.cbSize.TabIndex = 25;
            // 
            // btnCreatePet
            // 
            this.btnCreatePet.Location = new System.Drawing.Point(112, 506);
            this.btnCreatePet.Name = "btnCreatePet";
            this.btnCreatePet.Size = new System.Drawing.Size(94, 39);
            this.btnCreatePet.TabIndex = 26;
            this.btnCreatePet.Text = "Create Pet";
            this.btnCreatePet.UseVisualStyleBackColor = true;
            this.btnCreatePet.Click += new System.EventHandler(this.btnCreatePet_Click);
            // 
            // btnSaveAndExit
            // 
            this.btnSaveAndExit.Location = new System.Drawing.Point(277, 506);
            this.btnSaveAndExit.Name = "btnSaveAndExit";
            this.btnSaveAndExit.Size = new System.Drawing.Size(94, 39);
            this.btnSaveAndExit.TabIndex = 27;
            this.btnSaveAndExit.Text = "Save";
            this.btnSaveAndExit.UseVisualStyleBackColor = true;
            this.btnSaveAndExit.Click += new System.EventHandler(this.btnSaveAndExit_Click);
            // 
            // lbDisplay
            // 
            this.lbDisplay.FormattingEnabled = true;
            this.lbDisplay.ItemHeight = 16;
            this.lbDisplay.Location = new System.Drawing.Point(221, 275);
            this.lbDisplay.Name = "lbDisplay";
            this.lbDisplay.Size = new System.Drawing.Size(239, 148);
            this.lbDisplay.TabIndex = 28;
            this.lbDisplay.SelectedIndexChanged += new System.EventHandler(this.lbDisplay_SelectedIndexChanged);
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 557);
            this.Controls.Add(this.lbDisplay);
            this.Controls.Add(this.btnSaveAndExit);
            this.Controls.Add(this.btnCreatePet);
            this.Controls.Add(this.cbSize);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cbBreed);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnSleep);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnFeed);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.pbEnergy);
            this.Controls.Add(this.pbHappiness);
            this.Controls.Add(this.pbHunger);
            this.Controls.Add(this.lblEnergy);
            this.Controls.Add(this.lblHappiness);
            this.Controls.Add(this.lblHunger);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbGender);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPetColor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbSpecies);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPetName);
            this.Controls.Add(this.label1);
            this.Name = "form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPetName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbSpecies;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPetColor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbGender;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblHunger;
        private System.Windows.Forms.Label lblHappiness;
        private System.Windows.Forms.Label lblEnergy;
        private System.Windows.Forms.ProgressBar pbHunger;
        private System.Windows.Forms.ProgressBar pbHappiness;
        private System.Windows.Forms.ProgressBar pbEnergy;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Button btnFeed;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnSleep;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbBreed;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbSize;
        private System.Windows.Forms.Button btnCreatePet;
        private System.Windows.Forms.Button btnSaveAndExit;
        private System.Windows.Forms.ListBox lbDisplay;
    }
}

