﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Fakagachi_V3
{
    class Dog : VirtualPet
    {
        // Dog class inherits from VirtualPet
        public string Breed { get; set; }
        public string Size { get; set; }

        // Constructor for Dog class
        public Dog(string name, string species, string color, string gender, int hunger, int happiness, int energy, int age, bool isAlive, string breed, string size)
                        :base(name, species, color, gender, hunger, happiness, energy, age, isAlive)
        {
            Breed = breed;
            Size = size;
        }

        // Display method for Dog class
        public override string Display()
        {
            return base.Display(); 
            
        }

        // Overriding the Display method to show different attributes based on the number passed
        public override string Display(int num)
        {
            if (num == 1)
            {
                return Name;
            }
            else if (num == 2)
            {
                return Name + " " + Species;
            }
            else if (num == 3)
            {
                return Name + " " + Species + " " + Color;
            }
            else if (num == 4)
            {
                return Name + " " + Species + " " + Color + " " + Gender;
            }
            else if (num == 5)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger;
            }
            else if (num == 6)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness;
            }
            else if (num == 7)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy;
            }
            else if (num == 8)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy + " " + Age;
            }
            else if (num == 9)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy + " " + Age + " " + IsAlive;
            }
            else if (num == 10)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy + " " + Age + " " + IsAlive + " " + Breed;
            }
            else if (num == 11)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy + " " + Age + " " + IsAlive + " " + Breed + " " + Size;
            }
            else
            {
                return Name;
            }
        }
    }
}
