﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fakagachi_V3
{
    // Base class for all virtual pets
    class VirtualPet
    {
        // Properties for the VirtualPet class
        public string Name { get; set; }
        public string Species { get; set; }
        public string Color { get; set; }
        public string Gender { get; set; }
        public int Happiness { get; set; }
        public int Hunger { get; set; }
        public int Energy { get; set; }
        public int Age { get; set; }
        public bool IsAlive { get; set; }

        // Constructor for the VirtualPet class
        public VirtualPet(string name, string species, string color, string gender, int hunger, int happiness, int energy, int age, bool isAlive)
        {
            // Initialize properties
            Name = name;
            Species = species;
            Color = color;
            Gender = gender;
            Hunger = hunger;
            Happiness = happiness;
            Energy = energy;
            Age = age;
            IsAlive = isAlive;
           
        }

        public virtual string Display()
        {
            // Display the pet's name and species
            return Name + " (" + Species + ")";
        }

        public virtual string Display(int num)
        {
            // Overriding the Display method to show different attributes based on the number passed
            if (num == 1)
            {
                return Name;
            }
            else if (num == 2)
            {
                return Name + " " + Species;
            }
            else if (num == 3)
            {
                return Name + " " + Species + " " + Color;
            }
            else if (num == 4)
            {
                return Name+" " + Species+" " + Color+ " " + Gender;
            }
            else if (num == 5)
            {
                return Name + " " + Species + " " + Color + " " + Gender+ " " + Hunger;
            }
            else if (num == 6)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness;
            }
            else if (num == 7)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy;
            }
            else if (num == 8)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy + " " + Age;
            }
            else if (num == 9)
            {
                return Name + " " + Species + " " + Color + " " + Gender + " " + Hunger + " " + Happiness + " " + Energy + " " + Age + " " + IsAlive;
            }
            else
            {
                return Name;
            }

        }

        public virtual void Feed()
        {
            Hunger -= 10;
            if (Hunger < 0)
            {
                Hunger = 0;
            }
        }

        public virtual void Play()
        {
            Happiness += 10;
            if (Happiness > 100)
            {
                Happiness = 100;
            }
        }

        public virtual void Sleep()
        {
            Energy += 10;
            if (Energy > 100)
            {
                Energy = 100;
            }
        }


    }
}

