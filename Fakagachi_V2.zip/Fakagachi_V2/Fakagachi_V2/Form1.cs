﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace Fakagachi_V2
{
    public partial class MainScreen : Form
    {
        // Class to define a Virtual Pet
        public class VirtualPet
        {
            //  All of the global variable the will pass between all the different forms and functions.
            public string Name { get; set; }
            public int Hunger { get; set; }
            public int Happiness { get; set; }
            public int Energy { get; set; }
            public string Sex { get; set; }
            public string Species { get; set; }
            public string Color { get; set; }
            public string Age { get; set; }
            public bool IsAlive { get; set; } = true;

            public int Points { get; set; } = 0; // Points for the pet's happiness

            public VirtualPet(string name)
            {
                // Constructor to initialize the pet with a name and default values
                Name = name;
                Hunger = 50;
                Happiness = 50;
                Energy = 50;
                Points = 0;
            }

            public void Feed()
            {
                // Check if the pet is alive before feeding
                if (!IsAlive) return;

                // Default values for hunger, happiness, energy loss, and points gain
                int hungerGain = 10;
                int happinessGain = 5;
                int energyLoss = 0;


                // Switch case to determine the pet's species and adjust stats accordingly
                // I can add more species and their stats here if I want to expand.  Well add to the comboBox also.
                switch (Species)
                {
                    case "Dog":
                        hungerGain = 15;
                        happinessGain = 10;
                        energyLoss = 5;

                        break;
                    case "Cat":
                        hungerGain = 12;
                        happinessGain = 8;
                        energyLoss = 3;

                        break;
                    case "Bird":
                        hungerGain = 8;
                        happinessGain = 5;
                        energyLoss = 2;

                        break;
                    case "Fish":
                        hungerGain = 6;
                        happinessGain = 3;
                        energyLoss = 3;

                        break;
                    case "Reptile":
                        hungerGain = 7;
                        happinessGain = 3;
                        energyLoss = 1;

                        break;
                }


                // Math Logic to calculate the pet's stats and add points.  Using Math.Min and Math.Max to ensure values stay within bounds.
                Hunger = Math.Min(Hunger + hungerGain, 100);
                Happiness = Math.Min(Happiness + happinessGain, 100);
                Energy = Math.Max(Energy - energyLoss, 0);


            }

            public void Play()
            {
                // Check if the pet is alive before playing
                if (!IsAlive) return;

                // Default values for happiness gain and energy loss
                int happinessGain = 10;
                int energyLoss = 15;

                // Switch case to determine the pet's species and adjust stats accordingly
                switch (Species)
                {
                    case "Dog":
                        happinessGain = 15;
                        energyLoss = 20;
                        break;
                    case "Cat":
                        happinessGain = 12;
                        energyLoss = 10;
                        break;
                    case "Bird":
                        happinessGain = 8;
                        energyLoss = 5;
                        break;
                    case "Fish":
                        happinessGain = 6;
                        energyLoss = 2;
                        break;
                    case "Reptile":
                        happinessGain = 7;
                        energyLoss = 1;
                        break;
                }

                // Math Logic to calculate the pet's stats and add points.  Using Math.Min and Math.Max to ensure values stay within bounds.
                Happiness = Math.Min(Happiness + happinessGain, 100);
                Energy = Math.Max(Energy - energyLoss, 0);

            }

            public void Sleep()
            {
                // checks alive status then adjusted status
                if (!IsAlive) return;

                Energy += 20;
                Hunger -= 5;
                Happiness -= 5;

                switch (Species)
                {
                    case "Dog":
                        Energy += 25;
                        Hunger -= 10;
                        Happiness -= 5;
                        break;
                    case "Cat":
                        Energy += 20;
                        Hunger -= 8;
                        Happiness -= 3;
                        break;
                    case "Bird":
                        Energy += 15;
                        Hunger -= 5;
                        Happiness -= 2;
                        break;
                    case "Fish":
                        Energy += 10;
                        Hunger -= 2;
                        Happiness -= 1;
                        break;
                    case "Reptile":
                        Energy += 12;
                        Hunger -= 3;
                        Happiness -= 1;
                        break;
                }

                if (Happiness < 0) Happiness = 0;
                if (Hunger < 0) Hunger = 0;
                if (Energy > 100) Energy = 100;
            }
        }

        // Main form-level VirtualPet object
        private VirtualPet myPet;

        public MainScreen()
        {
            InitializeComponent();

            // Fill species combo box
            speciesComboBox.Items.Add("Dog");
            speciesComboBox.Items.Add("Cat");
            speciesComboBox.Items.Add("Bird");
            speciesComboBox.Items.Add("Fish");
            speciesComboBox.Items.Add("Reptile");
            speciesComboBox.SelectedIndex = 0;

            // Fill gender combo box
            genderComboBox.Items.Add("Mr.");
            genderComboBox.Items.Add("Ms.");
            genderComboBox.Items.Add("Mx.");
            genderComboBox.SelectedIndex = 0;


        }

        // Random color generator
        private string GetRandomColor()
        {
            string[] colors = { "Red", "Blue", "Green", "Yellow", "Purple", "Orange", "Pink", "Brown", "White", "Black" };
            Random rand = new Random();
            return colors[rand.Next(colors.Length)];
        }

        // Handle New Pet button click and moves all the information over to the global variables.
        private void newBtn_Click(object sender, EventArgs e)
        {
            string petName = nameTxt.Text.Trim();
            if (string.IsNullOrEmpty(petName))
            {
                //  Error handling for the new pet button.
                MessageBox.Show("Please enter a name for your pet!");
                return;
            }

            //  gets the information to manage the data.
            string selectedSpecies = speciesComboBox.SelectedItem?.ToString();
            string selectedGender = genderComboBox.SelectedItem?.ToString();
            string randomColor = GetRandomColor();

            // creates the myPet object.
            myPet = new VirtualPet(petName)
            {
                Species = selectedSpecies,
                Sex = selectedGender,
                Color = randomColor,
                Age = "0"
            };

            UpdatePetStatus();

            //  Creates the game screen and hides the Main screen.
            GameScreen form2 = new GameScreen(myPet);
            form2.Show();
            this.Hide();
        }

        // Update the pet's status labels
        private void UpdatePetStatus()
        {
            nameTxt.Text = myPet.Name;
            speciesComboBox.Text = myPet.Species;
            colorTxt.Text = myPet.Color;

        }


        // Function to load the saved pets.  This was really a pain in the @ss and I honestly almost regret the idea.
        private List<VirtualPet> LoadPets()
        {
            List<VirtualPet> loadedPets = new List<VirtualPet>();
            string filePath = "petsList.txt";

            // ERror handling for the load function.
            if (!File.Exists(filePath))
                return loadedPets; 

            // Read the file.
            string[] lines = File.ReadAllLines(filePath);

            // Parse section of the functions
            foreach (string line in lines)
            {
                if (string.IsNullOrWhiteSpace(line))
                    continue;

                // We expect exactly 10 fields.  Oh I see now that this is where it defines the delimiter.
                string[] parts = line.Split(',');
                if (parts.Length >= 10) 
                {
                    //Reads and address the data.
                    VirtualPet pet = new VirtualPet("")
                    {
                        Name = parts[0],
                        Sex = parts[1],
                        Species = parts[2],
                        Color = parts[3],
                        Age = parts[4],
                        Hunger = int.Parse(parts[5]),
                        Happiness = int.Parse(parts[6]),
                        Energy = int.Parse(parts[7]),
                        Points = int.Parse(parts[8]),
                        IsAlive = bool.Parse(parts[9])
                    };
                    loadedPets.Add(pet);
                }
            }

            return loadedPets;
        }

        // Loads the data into the VirtualPet class. 
        private void loadBtn_Click(object sender, EventArgs e)
        {
            List<VirtualPet> pets = LoadPets();

            // Error handle for the function 
            if (pets.Count == 0)
            {
                MessageBox.Show("No pets found!");
                return;
            }

            PetSelectionForm selectForm = new PetSelectionForm(pets);
            if (selectForm.ShowDialog() == DialogResult.OK)
            {
                // Load the Game Screen and hide the Saved Screen.
                VirtualPet petToLoad = selectForm.SelectedPet;
                GameScreen gameScreen = new GameScreen(petToLoad);
                gameScreen.Show();
                this.Hide();
            }
        }
    }
}
