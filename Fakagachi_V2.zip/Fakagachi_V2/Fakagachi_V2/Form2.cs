﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Fakagachi_V2.MainScreen;
using System.Xml;
using System.IO;
using System.Runtime.InteropServices;

namespace Fakagachi_V2
{
    public partial class GameScreen : Form
    {
        private VirtualPet myPet;
        private Timer petTimer;
        private List<VirtualPet> petList = new List<VirtualPet>();

        public GameScreen(VirtualPet pet)
        {
            InitializeComponent();
            myPet = pet;

            // Setup UI components based on the current pet data
            SetupPetUI();

            // Initialize UI with pet details
            nameLbl.Text = $"{myPet.Sex} {myPet.Name}";
            speciesLbl.Text = $"Species: {myPet.Species}";
            colorLbl.Text = $"Color: {myPet.Color}";
            ageLbl.Text = $"Age: {myPet.Age}";

            // Update all the status variable.
            UpdatePetStatus();

            // Set the pet image based on species
            SetPetImage();

            // Setup Timer for automatic updates.  Currently have a bug where the timer continues to run while pet is not loaded.  The pets will die will not loaded.  Working on this.
            petTimer = new Timer();
            // Timer to cause the status variable to go done and age to go up.
            petTimer.Interval = 5000; // every 5 seconds
            petTimer.Tick += PetTimer_Tick;
            petTimer.Start();
        }

        private void SetPetImage()
        {
            // Set the image based on the species
            switch (myPet.Species)
            {
                case "Dog":
                    petPic.Image = Properties.Resources.Dog; //  Pulls the assigned picture from resources
                    break;
                case "Cat":
                    petPic.Image = Properties.Resources.Cat; //  Pulls the assigned picture from resources
                    break;
                case "Bird":
                    petPic.Image = Properties.Resources.Bird; //  Pulls the assigned picture from resources
                    break;
                case "Fish":
                    petPic.Image = Properties.Resources.Fish; ///  Pulls the assigned picture from resources
                    break;
                case "Reptile":
                    petPic.Image = Properties.Resources.Reptile; //  Pulls the assigned picture from resources
                    break;
                default:
                    petPic.Image = Properties.Resources.Fakagchi; //  Pulls the assigned picture from resources
                    break;
            }
        }

        private void PetTimer_Tick(object sender, EventArgs e)
        {
            // Checks to see if the pet is Alive.  If is alive tries to make it unalive.
            if (!myPet.IsAlive) return;

            // Decrease pet stats every tick
            myPet.Hunger = Math.Max(myPet.Hunger - 5, 0);
            myPet.Happiness = Math.Max(myPet.Happiness - 3, 0);
            myPet.Energy = Math.Max(myPet.Energy - 2, 0);

            //Increase Score every tick
            if (myPet.Happiness > 80) myPet.Points += 1;

            int newAge = int.Parse(myPet.Age) + 1;
            myPet.Age = newAge.ToString();

            // Check for death conditions and makes the pet unalive.
            if (myPet.Hunger == 0 || myPet.Energy == 0)
            {
                myPet.IsAlive = false;
                petTimer.Stop();
                MessageBox.Show($"{myPet.Name} has passed away. 😢");
                this.Close();
            }

            // Updates the status of the pet
            UpdatePetStatus();
        }

        private void UpdatePetStatus()
        {
            // manages the status of the pets.
            hungerLbl.Text = $"Hunger: {myPet.Hunger}";
            happinessLbl.Text = $"Happiness: {myPet.Happiness}";
            energyLbl.Text = $"Energy: {myPet.Energy}";
            ageLbl.Text = $"Age: {myPet.Age}";
            scoreLbl.Text = $"Points: {myPet.Points}";

            // updates the visual indicators.
            hungerPBar.Value = myPet.Hunger;
            happinessPBar.Value = myPet.Happiness;
            energyPBar.Value = myPet.Energy;
        }

        private void feedBtn_Click(object sender, EventArgs e)
        {
            // Manages the feed button.
            myPet.Feed();
            UpdatePetStatus();
        }

        private void playBtn_Click(object sender, EventArgs e)
        {
            // Manages the play button.
            myPet.Play();
            UpdatePetStatus();
        }

        private void sleepBtn_Click(object sender, EventArgs e)
        {
            // Manages the sleep button
            myPet.Sleep();
            UpdatePetStatus();
        }

        private void SetupPetUI()
        {
            // Set the initial values for the pet's UI components
            hungerLbl.Text = $"Hunger: {myPet.Hunger}";
            happinessLbl.Text = $"Happiness: {myPet.Happiness}";
            energyLbl.Text = $"Energy: {myPet.Energy}";
            ageLbl.Text = $"Age: {myPet.Age}";
            scoreLbl.Text = $"Points: {myPet.Points}";
            hungerPBar.Maximum = 100;
            happinessPBar.Maximum = 100;
            energyPBar.Maximum = 100;
            hungerPBar.Value = myPet.Hunger;
            happinessPBar.Value = myPet.Happiness;
            energyPBar.Value = myPet.Energy;


        }

        private void saveAndExitBtn_Click(object sender, EventArgs e)
        {
            // Resets the status to default after saving the pet.
            SavePetData(myPet);
            myPet.Hunger = 50;
            myPet.Happiness = 50;
            myPet.Energy = 50;
            myPet.Age = "0";
            myPet.IsAlive = true;

            // Returns to the Main Screen.
            MainScreen form1 = new MainScreen();
            form1.Show();
            this.Hide();
        }

        private void SavePetData(VirtualPet pet)
        {
            // Save the pet to the txt file in the exe location.
            string filePath = "petsList.txt"; 
            string petLine = $"{pet.Name},{pet.Sex},{pet.Species},{pet.Color},{pet.Age},{pet.Hunger},{pet.Happiness},{pet.Energy},{pet.Points},{pet.IsAlive}";

            File.AppendAllText(filePath, petLine + Environment.NewLine);
        }

    }
}