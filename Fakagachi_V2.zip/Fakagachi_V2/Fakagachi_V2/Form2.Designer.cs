﻿namespace Fakagachi_V2
{
    partial class GameScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name = new System.Windows.Forms.Label();
            this.species = new System.Windows.Forms.Label();
            this.color = new System.Windows.Forms.Label();
            this.age = new System.Windows.Forms.Label();
            this.nameLbl = new System.Windows.Forms.Label();
            this.speciesLbl = new System.Windows.Forms.Label();
            this.colorLbl = new System.Windows.Forms.Label();
            this.ageLbl = new System.Windows.Forms.Label();
            this.petPic = new System.Windows.Forms.PictureBox();
            this.hungerLbl = new System.Windows.Forms.Label();
            this.happinessLbl = new System.Windows.Forms.Label();
            this.energyLbl = new System.Windows.Forms.Label();
            this.hungerPBar = new System.Windows.Forms.ProgressBar();
            this.happinessPBar = new System.Windows.Forms.ProgressBar();
            this.energyPBar = new System.Windows.Forms.ProgressBar();
            this.feedBtn = new System.Windows.Forms.Button();
            this.sleepBtn = new System.Windows.Forms.Button();
            this.playBtn = new System.Windows.Forms.Button();
            this.score = new System.Windows.Forms.Label();
            this.scoreLbl = new System.Windows.Forms.Label();
            this.saveAndExitBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.petPic)).BeginInit();
            this.SuspendLayout();
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(59, 42);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(137, 46);
            this.name.TabIndex = 0;
            this.name.Text = "Name:";
            // 
            // species
            // 
            this.species.AutoSize = true;
            this.species.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.species.Location = new System.Drawing.Point(59, 102);
            this.species.Name = "species";
            this.species.Size = new System.Drawing.Size(174, 46);
            this.species.TabIndex = 1;
            this.species.Text = "Species:";
            // 
            // color
            // 
            this.color.AutoSize = true;
            this.color.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color.Location = new System.Drawing.Point(59, 158);
            this.color.Name = "color";
            this.color.Size = new System.Drawing.Size(128, 46);
            this.color.TabIndex = 2;
            this.color.Text = "Color:";
            // 
            // age
            // 
            this.age.AutoSize = true;
            this.age.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.age.Location = new System.Drawing.Point(59, 204);
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(102, 46);
            this.age.TabIndex = 3;
            this.age.Text = "Age:";
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.Location = new System.Drawing.Point(242, 42);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(126, 46);
            this.nameLbl.TabIndex = 4;
            this.nameLbl.Text = "Name";
            // 
            // speciesLbl
            // 
            this.speciesLbl.AutoSize = true;
            this.speciesLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.speciesLbl.Location = new System.Drawing.Point(242, 102);
            this.speciesLbl.Name = "speciesLbl";
            this.speciesLbl.Size = new System.Drawing.Size(163, 46);
            this.speciesLbl.TabIndex = 5;
            this.speciesLbl.Text = "Species";
            // 
            // colorLbl
            // 
            this.colorLbl.AutoSize = true;
            this.colorLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colorLbl.Location = new System.Drawing.Point(242, 158);
            this.colorLbl.Name = "colorLbl";
            this.colorLbl.Size = new System.Drawing.Size(117, 46);
            this.colorLbl.TabIndex = 6;
            this.colorLbl.Text = "Color";
            // 
            // ageLbl
            // 
            this.ageLbl.AutoSize = true;
            this.ageLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ageLbl.Location = new System.Drawing.Point(242, 204);
            this.ageLbl.Name = "ageLbl";
            this.ageLbl.Size = new System.Drawing.Size(91, 46);
            this.ageLbl.TabIndex = 7;
            this.ageLbl.Text = "Age";
            // 
            // petPic
            // 
            this.petPic.Image = global::Fakagachi_V2.Properties.Resources.Reptile;
            this.petPic.Location = new System.Drawing.Point(426, 33);
            this.petPic.Name = "petPic";
            this.petPic.Size = new System.Drawing.Size(337, 244);
            this.petPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.petPic.TabIndex = 8;
            this.petPic.TabStop = false;
            // 
            // hungerLbl
            // 
            this.hungerLbl.AutoSize = true;
            this.hungerLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hungerLbl.Location = new System.Drawing.Point(48, 405);
            this.hungerLbl.Name = "hungerLbl";
            this.hungerLbl.Size = new System.Drawing.Size(150, 46);
            this.hungerLbl.TabIndex = 9;
            this.hungerLbl.Text = "Hunger";
            // 
            // happinessLbl
            // 
            this.happinessLbl.AutoSize = true;
            this.happinessLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.happinessLbl.Location = new System.Drawing.Point(48, 476);
            this.happinessLbl.Name = "happinessLbl";
            this.happinessLbl.Size = new System.Drawing.Size(208, 46);
            this.happinessLbl.TabIndex = 10;
            this.happinessLbl.Text = "Happiness";
            // 
            // energyLbl
            // 
            this.energyLbl.AutoSize = true;
            this.energyLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.energyLbl.Location = new System.Drawing.Point(48, 544);
            this.energyLbl.Name = "energyLbl";
            this.energyLbl.Size = new System.Drawing.Size(146, 46);
            this.energyLbl.TabIndex = 11;
            this.energyLbl.Text = "Energy";
            // 
            // hungerPBar
            // 
            this.hungerPBar.Location = new System.Drawing.Point(365, 404);
            this.hungerPBar.Name = "hungerPBar";
            this.hungerPBar.Size = new System.Drawing.Size(378, 47);
            this.hungerPBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.hungerPBar.TabIndex = 12;
            // 
            // happinessPBar
            // 
            this.happinessPBar.Location = new System.Drawing.Point(365, 476);
            this.happinessPBar.Name = "happinessPBar";
            this.happinessPBar.Size = new System.Drawing.Size(378, 47);
            this.happinessPBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.happinessPBar.TabIndex = 13;
            // 
            // energyPBar
            // 
            this.energyPBar.Location = new System.Drawing.Point(365, 544);
            this.energyPBar.Name = "energyPBar";
            this.energyPBar.Size = new System.Drawing.Size(378, 47);
            this.energyPBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.energyPBar.TabIndex = 14;
            // 
            // feedBtn
            // 
            this.feedBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feedBtn.Location = new System.Drawing.Point(43, 622);
            this.feedBtn.Name = "feedBtn";
            this.feedBtn.Size = new System.Drawing.Size(178, 64);
            this.feedBtn.TabIndex = 15;
            this.feedBtn.Text = "Feed";
            this.feedBtn.UseVisualStyleBackColor = true;
            this.feedBtn.Click += new System.EventHandler(this.feedBtn_Click);
            // 
            // sleepBtn
            // 
            this.sleepBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sleepBtn.Location = new System.Drawing.Point(275, 620);
            this.sleepBtn.Name = "sleepBtn";
            this.sleepBtn.Size = new System.Drawing.Size(215, 65);
            this.sleepBtn.TabIndex = 16;
            this.sleepBtn.Text = "Sleep";
            this.sleepBtn.UseVisualStyleBackColor = true;
            this.sleepBtn.Click += new System.EventHandler(this.sleepBtn_Click);
            // 
            // playBtn
            // 
            this.playBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playBtn.Location = new System.Drawing.Point(545, 622);
            this.playBtn.Name = "playBtn";
            this.playBtn.Size = new System.Drawing.Size(197, 63);
            this.playBtn.TabIndex = 17;
            this.playBtn.Text = "Play";
            this.playBtn.UseVisualStyleBackColor = true;
            this.playBtn.Click += new System.EventHandler(this.playBtn_Click);
            // 
            // score
            // 
            this.score.AutoSize = true;
            this.score.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.score.Location = new System.Drawing.Point(50, 262);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(137, 46);
            this.score.TabIndex = 18;
            this.score.Text = "Score:";
            // 
            // scoreLbl
            // 
            this.scoreLbl.AutoSize = true;
            this.scoreLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreLbl.Location = new System.Drawing.Point(233, 262);
            this.scoreLbl.Name = "scoreLbl";
            this.scoreLbl.Size = new System.Drawing.Size(126, 46);
            this.scoreLbl.TabIndex = 19;
            this.scoreLbl.Text = "Score";
            // 
            // saveAndExitBtn
            // 
            this.saveAndExitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveAndExitBtn.Location = new System.Drawing.Point(219, 726);
            this.saveAndExitBtn.Name = "saveAndExitBtn";
            this.saveAndExitBtn.Size = new System.Drawing.Size(351, 70);
            this.saveAndExitBtn.TabIndex = 20;
            this.saveAndExitBtn.Text = "Save and Exit";
            this.saveAndExitBtn.UseVisualStyleBackColor = true;
            this.saveAndExitBtn.Click += new System.EventHandler(this.saveAndExitBtn_Click);
            // 
            // GameScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 838);
            this.Controls.Add(this.saveAndExitBtn);
            this.Controls.Add(this.scoreLbl);
            this.Controls.Add(this.score);
            this.Controls.Add(this.playBtn);
            this.Controls.Add(this.sleepBtn);
            this.Controls.Add(this.feedBtn);
            this.Controls.Add(this.energyPBar);
            this.Controls.Add(this.happinessPBar);
            this.Controls.Add(this.hungerPBar);
            this.Controls.Add(this.energyLbl);
            this.Controls.Add(this.happinessLbl);
            this.Controls.Add(this.hungerLbl);
            this.Controls.Add(this.petPic);
            this.Controls.Add(this.ageLbl);
            this.Controls.Add(this.colorLbl);
            this.Controls.Add(this.speciesLbl);
            this.Controls.Add(this.nameLbl);
            this.Controls.Add(this.age);
            this.Controls.Add(this.color);
            this.Controls.Add(this.species);
            this.Controls.Add(this.name);
            this.Name = "GameScreen";
            this.Text = "Virtual Pet";
            ((System.ComponentModel.ISupportInitialize)(this.petPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label species;
        private System.Windows.Forms.Label color;
        private System.Windows.Forms.Label age;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label speciesLbl;
        private System.Windows.Forms.Label colorLbl;
        private System.Windows.Forms.Label ageLbl;
        private System.Windows.Forms.PictureBox petPic;
        private System.Windows.Forms.Label hungerLbl;
        private System.Windows.Forms.Label happinessLbl;
        private System.Windows.Forms.Label energyLbl;
        private System.Windows.Forms.ProgressBar hungerPBar;
        private System.Windows.Forms.ProgressBar happinessPBar;
        private System.Windows.Forms.ProgressBar energyPBar;
        private System.Windows.Forms.Button feedBtn;
        private System.Windows.Forms.Button sleepBtn;
        private System.Windows.Forms.Button playBtn;
        private System.Windows.Forms.Label score;
        private System.Windows.Forms.Label scoreLbl;
        private System.Windows.Forms.Button saveAndExitBtn;
    }
}