﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static Fakagachi_V2.MainScreen;


namespace Fakagachi_V2
{
    public partial class PetSelectionForm : Form

    {
        // Create the list to store the pets.
        private List<MainScreen.VirtualPet> pets;

        // Loads the pet into the selected pet variable
        public MainScreen.VirtualPet SelectedPet { get; private set; }

        public PetSelectionForm(List<MainScreen.VirtualPet> loadedPets)
        {
            InitializeComponent();
            pets = loadedPets;

            // Populate the list box with pet names.  Trying to load only pets where IsAlive = True, but I am having trouble with this feature. 
            // Currently storing and loading all pets.
            foreach (var pet in pets)
            {
                petListBox.Items.Add(pet.Name);
            }

            // Load top scores list into the listbox.
            LoadTopScores();
        }

        private void LoadTopScores()
        {
            // Set the path to the save file.  File is located in the exe file.
            string filePath = "petsList.txt";

            if (!File.Exists(filePath))
            {
                // Error handling if the file is not availabe.
                scoresListBox.Items.Add("No scores available!");
                return;
            }

            // Read the lines of the save file.
            var lines = File.ReadAllLines(filePath);

            // Parse section to read the .txt file.  I am a little confused here because the internet says it is comma delimited but txt is tab delimited.  It seems to work so I am taking the win.
            var topPets = lines
                .Where(line => !string.IsNullOrWhiteSpace(line))
                .Select(line =>
                {
                    // Sets the limit of fields it pulls to 10.
                    string[] parts = line.Split(',');
                    if (parts.Length >= 10)
                    {
                        // Creates the array that defines the fields in the txt file.  
                        // More accurate to say assigns an address to each value.
                        return new MainScreen.VirtualPet(parts[0])
                        {
                            Name = parts[0],
                            Sex = parts[1],
                            Species = parts[2],
                            Color = parts[3],
                            Age = parts[4],
                            Hunger = int.Parse(parts[5]),
                            Happiness = int.Parse(parts[6]),
                            Energy = int.Parse(parts[7]),
                            Points = int.Parse(parts[8]),
                            IsAlive = bool.Parse(parts[9])
                        };
                    }
                    return null;
                })
                // Sorts the list of saved pets by score takes the top 10 and adds to list.  Can add a variable here to change the number pulled for top score list.
                .Where(pet => pet != null)
                .OrderByDescending(pet => pet.Points)
                .Take(10)
                .ToList();

            //Clears and rebuild top score list with updated values.
            scoresListBox.Items.Clear();
            int rank = 1;
            foreach (var pet in topPets)
            {
                scoresListBox.Items.Add($"#{rank++}: {pet.Name} the {pet.Species} - {pet.Points} pts");
            }
        }

        //  Load function to load the saved pets.  You have to be able to get them back out after all.
        private void loadSelectedBtn_Click(object sender, EventArgs e)
        {
            // Error handling for the load functions.
            if (petListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a pet to load!");
                return;
            }

            SelectedPet = pets[petListBox.SelectedIndex];
            DialogResult = DialogResult.OK;
            Close();
        }
    }



}