﻿namespace Fakagachi_V2
{
    partial class PetSelectionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.petListBox = new System.Windows.Forms.ListBox();
            this.loadSelectedBtn = new System.Windows.Forms.Button();
            this.scoresListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // petListBox
            // 
            this.petListBox.FormattingEnabled = true;
            this.petListBox.ItemHeight = 16;
            this.petListBox.Location = new System.Drawing.Point(69, 104);
            this.petListBox.Name = "petListBox";
            this.petListBox.Size = new System.Drawing.Size(280, 116);
            this.petListBox.TabIndex = 0;
            // 
            // loadSelectedBtn
            // 
            this.loadSelectedBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadSelectedBtn.Location = new System.Drawing.Point(214, 792);
            this.loadSelectedBtn.Name = "loadSelectedBtn";
            this.loadSelectedBtn.Size = new System.Drawing.Size(303, 81);
            this.loadSelectedBtn.TabIndex = 1;
            this.loadSelectedBtn.Text = "Load";
            this.loadSelectedBtn.UseVisualStyleBackColor = true;
            this.loadSelectedBtn.Click += new System.EventHandler(this.loadSelectedBtn_Click);
            // 
            // scoresListBox
            // 
            this.scoresListBox.FormattingEnabled = true;
            this.scoresListBox.ItemHeight = 16;
            this.scoresListBox.Location = new System.Drawing.Point(462, 104);
            this.scoresListBox.Name = "scoresListBox";
            this.scoresListBox.Size = new System.Drawing.Size(297, 116);
            this.scoresListBox.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(71, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(230, 46);
            this.label1.TabIndex = 3;
            this.label1.Text = "Crated Pets";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(454, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(478, 115);
            this.label2.TabIndex = 4;
            this.label2.Text = "Best Pets";
            // 
            // PetSelectionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 909);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.scoresListBox);
            this.Controls.Add(this.loadSelectedBtn);
            this.Controls.Add(this.petListBox);
            this.Name = "PetSelectionForm";
            this.Text = "Get a pet out of the crate";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox petListBox;
        private System.Windows.Forms.Button loadSelectedBtn;
        private System.Windows.Forms.ListBox scoresListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}