﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using Timer = System.Windows.Forms.Timer;
using System.Data.SqlClient;
using System.Data;
using System.Drawing.Drawing2D;
using System.Windows;
using System.Xml.Linq;
using System.Web;
using System.Net.PeerToPeer;


namespace Fakagachi_V3
{
    public partial class CreationScreen : Form
    {
        private Random rand = new Random(); // Used for color generation

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\dbVirtualPet.mdf;Integrated Security=True";

        string name;
        string currentPlayer;

        public CreationScreen(string name)
        {
            InitializeComponent();
            this.name = name;
            this.currentPlayer = name;
            InitializeFormElements();
            
            
        }

        private void InitializeFormElements()
        {

            // Initialize combo boxes with default values
            cbSpecies.Items.AddRange(new string[] { "Dog", "Cat", "Bird", "Reptile" });
            cbSpecies.SelectedIndex = 0;

            cbGender.Items.AddRange(new string[] { "Mr.", "Mrs.", "Miss", "Mx." });
            cbGender.SelectedIndex = 0;

            cbSize.Items.AddRange(new string[] { "Small", "Medium", "Large", "X Large" });
            cbSize.SelectedIndex = 0;

            txtPetColor.Text = GetRandomColor();

            cbSpecies.SelectedIndexChanged += cbSpecies_SelectedIndexChanged;
            PopulateBreedComboBox(cbSpecies.SelectedItem.ToString());
        }

        private void CreationScreen_Load(object sender, EventArgs e)
        {

        }

        private void PopulateBreedComboBox(string species)
        {
            // Clear the breed combo box before adding new items
            cbBreed.Items.Clear();
            //  Changes the breed list based on the selected species.
            switch (species)
            {
                case "Dog":
                    cbBreed.Items.AddRange(new string[] { "Labrador", "Poodle", "Bulldog", "Beagle" });
                    break;
                case "Cat":
                    cbBreed.Items.AddRange(new string[] { "Siamese", "Persian", "Maine Coon", "Sphynx" });
                    break;
                case "Bird":
                    cbBreed.Items.AddRange(new string[] { "Parrot", "Canary", "Finch", "Cockatiel" });
                    break;
                case "Reptile":
                    cbBreed.Items.AddRange(new string[] { "Gecko", "Iguana", "Snake", "Chameleon" });
                    break;
            }

            // Set the first breed as selected if available
            if (cbBreed.Items.Count > 0)
                cbBreed.SelectedIndex = 0;
        }

        private string GetRandomColor()
        {
            string[] colors = { "Red", "Blue", "Green", "Yellow", "Purple", "Orange", "Pink", "Brown", "White", "Black" };
            return colors[rand.Next(colors.Length)];
        }
        private void cbSpecies_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateBreedComboBox(cbSpecies.SelectedItem.ToString());

            switch (cbSpecies.SelectedItem.ToString())
            {
                case "Dog":
                    lblSpecial1.Text = "Tail Wag Impact";
                    cbSpecial1.Items.Clear();
                    cbSpecial1.Items.AddRange(new string[] { "Low", "Medium", "High" });
                    lblSpecial2.Text = "Zoomies";
                    cbSpecial2.Items.Clear();
                    cbSpecial2.Items.AddRange(new string[] { "Yes", "No" });
                    break;
                case "Cat":
                    lblSpecial1.Text = "Claw Likely";
                    cbSpecial1.Items.Clear();
                    cbSpecial1.Items.AddRange(new string[] { "Low", "Medium", "High" });
                    lblSpecial2.Text = "Favorite Toy";
                    cbSpecial2.Items.Clear();
                    cbSpecial2.Items.AddRange(new string[] { "Ball", "String", "Laser Pointer", "Feather" });
                    break;
                case "Bird":
                    lblSpecial1.Text = "Flight";
                    cbSpecial1.Items.Clear();
                    cbSpecial1.Items.AddRange(new string[] { "Yes", "No" });
                    lblSpecial2.Text = "Nest Size";
                    cbSpecial2.Items.Clear();
                    cbSpecial2.Items.AddRange(new string[] { "Small", "Medium", "Large" });
                    break;
                case "Reptile":
                    lblSpecial1.Text = "Habitat";
                    cbSpecial1.Items.Clear();
                    cbSpecial1.Items.AddRange(new string[] { "Desert", "Rainforest", "Aquatic", "Forrest" });
                    lblSpecial2.Text = "Requires Heat";
                    cbSpecial2.Items.Clear();
                    cbSpecial2.Items.AddRange(new string[] { "Yes", "No" });
                    break;
            }
        }

        private void btnPetCreation_Click(object sender, EventArgs e)
        {
            // Base data (common to all pets)
            string name = txtPetsName.Text;
            string species = cbSpecies.SelectedItem.ToString();
            string color = txtPetColor.Text;
            string gender = cbGender.SelectedItem.ToString();
            string breed = cbBreed.SelectedItem.ToString();
            string size = cbSize.SelectedItem.ToString();

            // Species-specific properties
            string wagImpact = null;
            string zoomies = null;
            string likelyClaw = null;
            string favToy = null;
            string flight = null;
            string nestSize = null;
            string habitat = null;
            string requiresHeat = null;

            // Set species-specific properties
            if (species.ToLower() == "dog")
            {
                wagImpact = cbSpecial1.SelectedItem?.ToString() ?? " ";
                zoomies = cbSpecial2.SelectedItem?.ToString() ?? " ";
            }
            else if (species.ToLower() == "cat")
            {
                likelyClaw = cbSpecial1.SelectedItem?.ToString() ?? " ";
                favToy = cbSpecial2.SelectedItem?.ToString() ?? " ";
            }
            else if (species.ToLower() == "bird")
            {
                flight = cbSpecial1.SelectedItem?.ToString() ?? " ";
                nestSize = cbSpecial2.SelectedItem?.ToString() ?? " ";
            }
            else if (species.ToLower() == "reptile")
            {
                habitat = cbSpecial1.SelectedItem?.ToString() ?? " ";
                requiresHeat = cbSpecial2.SelectedItem?.ToString() ?? " ";
            }

            // Create the pet with the properties passed directly
            VirtualPet virtualPet = PetFactory.CreatePet(
                name,
                species,
                color,
                gender,
                50,  // Hunger
                50,  // Happiness
                50,  // Energy
                0,   // Age
                true, // IsAlive
                breed,
                size,
                wagImpact,  // For dog: WagImpact
                zoomies,    // For dog: Zoomies
                likelyClaw, // For cat: LikelyClaw
                favToy,     // For cat: FavToy
                flight,     // For bird: Flight
                nestSize,   // For bird: NestSize
                habitat,    // For reptile: Habitat
                requiresHeat // For reptile: RequiresHeat
            );

            //InsertPet(virtualPet.Name, virtualPet.Gender, virtualPet.Breed, virtualPet.Species);
            
            MessageBox.Show("Pet created and saved successfully!");

            GameScreen gameScreen = new GameScreen(virtualPet);
            gameScreen.Show(); // Show the new form
            this.Hide(); // Hide the current form
        }

        public void InsertPet(string currentPlayer, string species, string gender, string breed)
        {
            string strConnString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\allen\source\repos\Fakagachi_V3\Fakagachi_V3\bin\Debug\VirtualPet.mdf;Integrated Security=True";

            string strQuery = @" INSERT INTO tblAddedPets
                                (Player_Name,Species,Gender,Breed)
                                VALUES
                                (@Player_Name,@Species,@Gender,@Breed)";


            using (SqlConnection connection = new SqlConnection(strConnString))
            using (SqlCommand cmd = new SqlCommand(strQuery, connection))
            {
                cmd.Parameters.AddWithValue("@Player_Name", currentPlayer);
                cmd.Parameters.AddWithValue("@Species", species);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Breed", breed);

                connection.Open();

                cmd.ExecuteNonQuery();

                connection.Close();
            }

        }




    }



 }

