﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Fakagachi_V3
{
    public partial class GameScreen : Form
    {
        private VirtualPet currentPet;        // The currently selected pet
        private string currentPlayer;         // Currently logged-in player (unused here, but ready for expansion)
        private Timer petStatsTimer;          // Timer that decreases pet stats over time

        public GameScreen(VirtualPet pet)
        {
            InitializeComponent();
            currentPet = pet;
            LoadPetData();                    // Populate UI with initial pet data
        }

        
        // Load pet attributes and species-specific traits into listboxes.
        
        private void LoadPetData()
        {
            lbDetails.Items.Clear();
            lbSpecial.Items.Clear();

            // Base stats
            lbDetails.Items.Add($"Name: {currentPet.Name}");
            lbDetails.Items.Add($"Species: {currentPet.Species}");
            lbDetails.Items.Add($"Breed: {currentPet.Breed}");
            lbDetails.Items.Add($"Gender: {currentPet.Gender}");
            lbDetails.Items.Add($"Color: {currentPet.Color}");
            lbDetails.Items.Add($"Size: {currentPet.Size}");
            lbDetails.Items.Add($"Age: {currentPet.Age}");

            // Species-specific traits set by the subclasses
            switch (currentPet)
            {
                case Dog dog:
                    lbSpecial.Items.Add($"Wag Impact: {dog.WagImpact}");
                    lbSpecial.Items.Add($"Zoomies: {dog.Zoomies}");
                    break;
                case Cat cat:
                    lbSpecial.Items.Add($"Likely Claw: {cat.LikelyClaw}");
                    lbSpecial.Items.Add($"Favorite Toy: {cat.FavToy}");
                    break;
                case Bird bird:
                    lbSpecial.Items.Add($"Flight: {bird.Flight}");
                    lbSpecial.Items.Add($"Nest Size: {bird.NestSize}");
                    break;
                case Reptile reptile:
                    lbSpecial.Items.Add($"Habitat: {reptile.Habitat}");
                    lbSpecial.Items.Add($"Requires Heat: {reptile.RequiresHeat}");
                    break;
            }
        }

       
        /// Initializes the timer and sets the initial UI values.
        
        private void GameScreen_Load(object sender, EventArgs e)
        {
            // Set up timer for pet stat decay
            petStatsTimer = new Timer
            {
                Interval = 5000 // 5 seconds
            };
            petStatsTimer.Tick += PetStatsTimer_Tick;
            petStatsTimer.Start();

            // Display initial values
            UpdateActivePetUI(); 
        }

        
        // Timer tick: reduces stats and checks if the pet is still alive.
        
        private void PetStatsTimer_Tick(object sender, EventArgs e)
        {
            if (!currentPet.IsAlive) return;

            // Let the pet manage its own stat logic (defined in VirtualPet class)
            currentPet.Tick(); 

            if (!currentPet.IsAlive)
            {
                MessageBox.Show($"{currentPet.Name} has passed away.");
                this.Close(); // Close the game screen
            }
            // Update the UI with the new stats
            UpdateActivePetUI(); // Refresh UI
        }

        
        /// Updates the hunger, happiness, and energy labels and progress bars.
       
        private void UpdateActivePetUI()
        {
            // Update labels and progress bars with current pet stats
            lblHungerVal.Text = currentPet.Hunger.ToString();
            lblHappinessVal.Text = currentPet.Happiness.ToString();
            lblEngeryVal.Text = currentPet.Energy.ToString();

            // Update progress bars
            pbHungerVal.Value = currentPet.Hunger;
            pbHappinessVal.Value = currentPet.Happiness;
            pbEnergyVal.Value = currentPet.Energy;
           
        }

        
        /// Feeds the pet. Reduces hunger, increases happiness and energy.
        
        private void btnFeed_Click(object sender, EventArgs e)
        {
            // Check if the pet is alive before performing actions
            if (!currentPet.IsAlive)
            {
                MessageBox.Show($"{currentPet.Name} is no longer with us.");
                return;
            }
            // Feed the pet
            currentPet.Hunger = Math.Max(0, currentPet.Hunger - 10);
            currentPet.Happiness += 5;
            currentPet.Energy += 2;
            //  Update the UI
            UpdateActivePetUI();
        }

        
        // Plays with the pet. Increases happiness, decreases energy.
        
        private void btnPlay_Click(object sender, EventArgs e)
        {
            // Check if the pet is alive before performing actions
            if (!currentPet.IsAlive)
            {
                MessageBox.Show($"{currentPet.Name} is no longer with us.");
                return;
            }
            // Play with the pet
            currentPet.Happiness += 10;
            currentPet.Energy = Math.Max(0, currentPet.Energy - 5);
            // Update the UI
            UpdateActivePetUI();
        }

      
        // Puts the pet to sleep. Increases energy, reduces happiness slightly.
       
        private void btnSleep_Click(object sender, EventArgs e)
        {
            // Check if the pet is alive before performing actions
            if (!currentPet.IsAlive)
            {
                MessageBox.Show($"{currentPet.Name} is no longer with us.");
                return;
            }
            // Put the pet to sleep
            currentPet.Energy += 20;
            currentPet.Happiness = Math.Max(0, currentPet.Happiness - 2);

            // Update the UI
            UpdateActivePetUI();
        }

   
        // Saves and exits to the start screen.
     
        private void btnSaveExit_Click(object sender, EventArgs e)
        {
            // FUture: Implement save functionality to database  Still having some trouble with the database connection.
            StartScreen startScreen = new StartScreen();
            startScreen.Show();
            this.Hide();
        }
    }
}
