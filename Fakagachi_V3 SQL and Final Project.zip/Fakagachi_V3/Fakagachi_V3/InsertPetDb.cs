﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Fakagachi_V3
{
    internal class InsertPetDb
    {
        public void InsertPet(string name, string species, string color, string currentPlayer, string gender, string breed)
        {
            string strConnString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\allen\source\repos\Fakagachi_V3\Fakagachi_V3\bin\Debug\VirtualPet.mdf;Integrated Security=True";
          
            string strQuery = @" INSERT INTO tblPet
                                (Player_Name,Species_ID,Color,Gender,Breed,Size)
                                VALUES
                                (@Player_Name,@Species_ID,@Color,@Gender,@Breed,@Size)";


            using (SqlConnection connection = new SqlConnection(strConnString))
            using (SqlCommand cmd = new SqlCommand(strQuery, connection))
            {
                cmd.Parameters.AddWithValue("@Player_Name", currentPlayer);
                cmd.Parameters.AddWithValue("@Species_ID", species);
                cmd.Parameters.AddWithValue("@Color", color);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Breed", breed);

                connection.Open();

                cmd.ExecuteNonQuery();

                connection.Close();

            }

        }
    }
}
