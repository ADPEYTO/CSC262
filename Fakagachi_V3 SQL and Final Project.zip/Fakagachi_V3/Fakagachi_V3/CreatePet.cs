﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fakagachi_V3
{
    public static class PetFactory
    {
        public static VirtualPet CreatePet(
            string name,
            string species,
            string color,
            string gender,
            int hunger,
            int happiness,
            int energy,
            int age,
            bool isAlive,
            string breed,
            string size,
            string wagImpact = null,
            string zoomies = null,
            string likelyClaw = null,
            string favToy = null,
            string flight = null,
            string nestSize = null,
            string habitat = null,
            string requiresHeat = null)
        {
            switch (species.ToLower())
            {
                case "dog":
                    return new Dog(name, species, color, gender, hunger, happiness, energy, age, isAlive, breed, size, wagImpact, zoomies);

                case "cat":
                    return new Cat(name, species, color, gender, hunger, happiness, energy, age, isAlive, breed, size, likelyClaw, favToy);

                case "bird":
                    return new Bird(name, species, color, gender, hunger, happiness, energy, age, isAlive, breed, size, flight, nestSize);

                case "reptile":
                    return new Reptile(name, species, color, gender, hunger, happiness, energy, age, isAlive, breed, size, habitat, requiresHeat);

                default:
                    return new VirtualPet(name, species, color, gender, hunger, happiness, energy, age, isAlive, breed, size);
            }
        }
    }


}
