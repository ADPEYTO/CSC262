﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fakagachi_V3
{
    public partial class StartScreen : Form
    {
        public StartScreen()
        {
            InitializeComponent();
        }

        private void StartScreen_Load(object sender, EventArgs e)
        {

        }

        private void btnCreatePet_Click(object sender, EventArgs e)
        {
            string name = txtPlayer.Text;
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Please enter a name for your player.");
                return;
            }
            Player player = new Player(name);

            GameSession.CurrentPlayer = new Player(name);

            // Open the CreationScreen with the player's name
            CreationScreen creationScreen = new CreationScreen(name);
            creationScreen.Show();
            this.Hide(); // optional: hide the start screen
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadPets loadPets = new LoadPets();
            loadPets.Show();
            this.Hide(); // optional: hide the start screen
        }
    }
}
