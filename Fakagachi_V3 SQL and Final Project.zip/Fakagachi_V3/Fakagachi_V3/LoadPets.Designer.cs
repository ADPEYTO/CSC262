﻿namespace Fakagachi_V3
{
    partial class LoadPets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvPastPets = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPastPets)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvPastPets
            // 
            this.dgvPastPets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPastPets.Location = new System.Drawing.Point(25, 104);
            this.dgvPastPets.Name = "dgvPastPets";
            this.dgvPastPets.RowHeadersWidth = 51;
            this.dgvPastPets.RowTemplate.Height = 24;
            this.dgvPastPets.Size = new System.Drawing.Size(1084, 265);
            this.dgvPastPets.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(499, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Past Pets";
            // 
            // LoadPets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvPastPets);
            this.Name = "LoadPets";
            this.Text = "LoadPets";
            this.Load += new System.EventHandler(this.LoadPets_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPastPets)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPastPets;
        private System.Windows.Forms.Label label1;
    }
}