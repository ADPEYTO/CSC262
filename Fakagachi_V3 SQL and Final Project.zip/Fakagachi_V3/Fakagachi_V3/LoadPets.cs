﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Fakagachi_V3
{
    public partial class LoadPets : Form
    {
        private object connection;

        public LoadPets()
        {
            InitializeComponent();
        }

        private void LoadPets_Load(object sender, EventArgs e)
        {
            // Load the data from the database into the DataGridView
            // Build the connection string
            string strConnString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\allen\source\repos\Fakagachi_V3\Fakagachi_V3\bin\Debug\VirtualPet.mdf;Integrated Security=True";
            // Build the SQL query to select all records from the tblPet table
            string strQuery = "SELECT * FROM tblPet";

            // Create a new SqlConnection object with the connection string
            using (SqlConnection connection = new SqlConnection(strConnString))
            {
                // Create a new SqlCommand object with the SQL query and connection and Open the connection
                connection.Open();

                // Get the data and populate the DataGridView
                using (SqlDataAdapter adapter = new SqlDataAdapter(strQuery, connection))
                {
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dgvPastPets.DataSource = table;
                }


                // FOr the love of god, please remember to close the connection...  IF not the whole world will end.
                connection.Close();
            }
        }

    }
}
