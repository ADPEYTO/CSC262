﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fakagachi_V3
{
    public class Player
    {
        public string Name { get; set; }
        public List<VirtualPet> Pets { get; set; }

        public Player(string name)
        {
            Name = name;
            Pets = new List<VirtualPet>();
        }

        public void AddPet(VirtualPet pet)
        {
            Pets.Add(pet);
        }
    }

}
