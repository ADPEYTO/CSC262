﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fakagachi_V3
{
    public static class GameSession
    {
        public static Player CurrentPlayer { get; set; }
    }
}
