﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using Timer = System.Windows.Forms.Timer;
using System.Data.SqlClient;
using System.Data;

namespace Fakagachi_V3
{
    public partial class form1 : Form
    {
        /// List to store all created pets
        private List<VirtualPet> petList = new List<VirtualPet>(); // All created pets
        private Random rand = new Random(); // Used for color generation
        private VirtualPet activePet = null; // Currently selected pet
        private Timer petStatsTimer; // Timer for stat decay

        public form1()
        {
            InitializeComponent();
            InitializeFormElements();
           
        }

        
        private void InitializeFormElements()
        {

            // Initialize combo boxes with default values
            cbSpecies.Items.AddRange(new string[] { "Dog", "Cat", "Bird", "Reptile" });
            cbSpecies.SelectedIndex = 0;

            cbGender.Items.AddRange(new string[] { "Mr.", "Mrs.", "Miss", "Mx." });
            cbGender.SelectedIndex = 0;

            cbSize.Items.AddRange(new string[] { "Small", "Medium", "Large", "X Large" });
            cbSize.SelectedIndex = 0;

            txtPetColor.Text = GetRandomColor();

            cbSpecies.SelectedIndexChanged += cbSpecies_SelectedIndexChanged;
            PopulateBreedComboBox(cbSpecies.SelectedItem.ToString());
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Holy crap that was way harder than it should have been.  My computer did not want to do the SQL stuff.
            // Initialize and start timer for stat decay
            petStatsTimer = new Timer();
            petStatsTimer.Interval = 5000; // Every 5 seconds
            petStatsTimer.Tick += PetStatsTimer_Tick;
            petStatsTimer.Start();

            // Exact copy of what you did in class.  I know that will work when I send you the code.
            string strConnString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\allen\source\repos\Fakagachi_V3\Fakagachi_V3\bin\Debug\VirtualPet.mdf;Integrated Security=True;Connect Timeout=30;Initial Catalog=FakagachiDB";

            string strQuery = "SELECT * FROM dbo.tblVirtualPet";

            using (SqlConnection connection = new SqlConnection(strConnString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand())
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(strQuery, strConnString);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dgvVirtualPet.DataSource = table;
                }
            }



        }



        // Generate a random color name
        private string GetRandomColor()
        {
            string[] colors = { "Red", "Blue", "Green", "Yellow", "Purple", "Orange", "Pink", "Brown", "White", "Black" };
            return colors[rand.Next(colors.Length)];
        }

        // Populate breed list based on selected species
        private void PopulateBreedComboBox(string species)
        {
            // Clear the breed combo box before adding new items
            cbBreed.Items.Clear();
            //  Changes the breed list based on the selected species.
            switch (species)
            {
                case "Dog":
                    cbBreed.Items.AddRange(new string[] { "Labrador", "Poodle", "Bulldog", "Beagle" });
                    break;
                case "Cat":
                    cbBreed.Items.AddRange(new string[] { "Siamese", "Persian", "Maine Coon", "Sphynx" });
                    break;
                case "Bird":
                    cbBreed.Items.AddRange(new string[] { "Parrot", "Canary", "Finch", "Cockatiel" });
                    break;
                case "Reptile":
                    cbBreed.Items.AddRange(new string[] { "Gecko", "Iguana", "Snake", "Chameleon" });
                    break;
            }

            // Set the first breed as selected if available
            if (cbBreed.Items.Count > 0)
                cbBreed.SelectedIndex = 0;
        }

        // Show all pets in the listbox
        private void DisplayAllPets()
        {
            lbDisplay.Items.Clear();
            foreach (var pet in petList)
            {
                lbDisplay.Items.Add(pet.Display(3)); // Show brief pet info
            }
        }

        // Update progress bars and labels for the active pet
        private void UpdateActivePetUI()
        {
            //If a pet is selected in the listbox, update the UI with its stats.
            if (activePet == null) return;

            lblHunger.Text = activePet.Hunger.ToString();
            lblHappiness.Text = activePet.Happiness.ToString();
            lblEnergy.Text = activePet.Energy.ToString();

            pbHunger.Value = activePet.Hunger;
            pbHappiness.Value = activePet.Happiness;
            pbEnergy.Value = activePet.Energy;
        }

        

        private void cbSpecies_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateBreedComboBox(cbSpecies.SelectedItem.ToString());
        }

        // Create and store a new pet
        private void btnCreatePet_Click(object sender, EventArgs e)
        {
            string name = txtPetName.Text;
            string species = cbSpecies.SelectedItem.ToString();
            string color = txtPetColor.Text;
            string gender = cbGender.SelectedItem.ToString();
            string breed = cbBreed.SelectedItem.ToString();
            string size = cbSize.SelectedItem.ToString();

           

           

            txtPetColor.Text = GetRandomColor(); // Assign a new color for the next pet
        }

        // Set selected pet as active
        private void lbDisplay_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = lbDisplay.SelectedIndex;
            if (index >= 0 && index < petList.Count)
            {
                activePet = petList[index];
                MessageBox.Show(activePet.Display(3), "Pet Details");
                UpdateActivePetUI();
            }
        }

        // Feed active pet
        private void btnFeed_Click(object sender, EventArgs e)
        {
            //if a pet is selected do this.
            if (activePet == null)
            {
                MessageBox.Show("No active pet selected. Please select a pet from the list.");
                return;
            }
            //Feed the pet
            activePet.Feed();
            UpdateActivePetUI();
        }

        // Play with active pet
        private void btnPlay_Click(object sender, EventArgs e)
        {
            //if a pet is selected do this.
            if (activePet == null)
            {
                MessageBox.Show("No active pet selected. Please select a pet from the list.");
                return;
            }
            //Play with the pet
            activePet.Play();
            UpdateActivePetUI();
        }

        // Put active pet to sleep
        private void btnSleep_Click(object sender, EventArgs e)
        {    //if a pet is selected do this.
            if (activePet == null)
            {
                MessageBox.Show("No active pet selected. Please select a pet from the list.");
                return;
            }
            //Sleep with the pet.... No wait that's not right. Put the pet to sleep.  That doesnot sound right either... ;)
            activePet.Sleep();
            UpdateActivePetUI();
        }

        // Save and reset pet state (optional exit prep)
        private void btnSaveAndExit_Click(object sender, EventArgs e)
        {
            //Unselects the pet in the listbox and clears the active pet
            lbDisplay.SelectedIndex = -1;
            activePet = null;

            // Clear the pet list and UI elements
            lblEnergy.Text = "0";
            lblHappiness.Text = "0";
            lblHunger.Text = "0";

            // Reset progress bars
            pbEnergy.Value = 0;
            pbHappiness.Value = 0;
            pbHunger.Value = 0;

            lblAge.Text = "0";

            // Update the UI
            UpdateActivePetUI();
        }

        // Timer tick: simulate stat decay
        private void PetStatsTimer_Tick(object sender, EventArgs e)
        {
            // Check if an active pet is selected.  This does not seem to be working.  I know the != null is correct.
            // but can not figure out why it is not working.

            if (activePet != null)
            {
                // Decrease stats over time
                activePet.Hunger = Math.Min(activePet.Hunger + 2, 100);      // Increases hunger
                activePet.Happiness = Math.Max(activePet.Happiness - 1, 0);  // Decreases happiness
                activePet.Energy = Math.Max(activePet.Energy - 1, 0);        // Decreases energy

                //Debugging that is not triggering so I know it is not working.
                Console.WriteLine("Timer ticked. Active pet: " + (activePet?.Name ?? "None"));

                //Theroetically this should be updating the UI.
                UpdateActivePetUI(); // Reflect changes in the UI
            }
        }


    }
}
