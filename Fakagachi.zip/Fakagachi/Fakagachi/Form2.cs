﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fakagachi
{
    public partial class petForm : Form
    {
        public petForm()
        {
            InitializeComponent();
        }

        private void btnFeed_Click(object sender, EventArgs e)
        {
            _pet.Feed();
            UpdateStatusBars();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            _pet.Play();
            UpdateStatusBars();
        }

        private void btnSleep_Click(object sender, EventArgs e)
        {
            _pet.Sleep();
            UpdateStatusBars();
        }

        
    }
}

