﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Fakagachi
{
    public class VirtualPet
    {
        //Class to hold all the items that I am using to run the Fakagachi.
        //Name obiviously the name.
        //Age not really used yet but I plan on adding it in the future.
        //Hunger variable
        //Happiness variable
        //Energy Variable

        public string Name { get; set; }
        public int Age { get; set; }
        public int Hunger { get; set; }
        public int Happiness { get; set; }
        public int Energy { get; set; }

        public VirtualPet(string name, int age)
        {
            //Set the values of the items.  Defualt starting values.  If a continue with the I would make this based on pet type. Dog, cat, bird, etc....
            Name = name;
            Age = age;
            Hunger = 30;
            Happiness = 50;
            Energy = 70;
        }

        public void Feed()
        {
            // Public function to adjust class values on click.  Was private but would not function when I added form2... Big eye roll.
            Hunger = Math.Max(0, Hunger - 25);
            Energy = Math.Min(100, Energy + 10);
        }

        public void Play()
        {
            // Public function to adjust class values on click.  Was private but would not function when I added form2... Big eye roll.
            Happiness = Math.Min(100, Happiness + 20);
            Energy = Math.Max(0, Energy - 15);
            Hunger = Math.Min(100, Hunger + 10);
        }

        public void Sleep()
        {
            // Public function to adjust class values on click.  Was private but would not function when I added form2... Big eye roll.
            Energy = Math.Min(100, Energy + 30);
            Happiness = Math.Max(0, Happiness + 20);
            Hunger = Math.Min(100, Hunger + 5);
        }

        public void IncrementAge() => Age++;  // Function to increase age of the pet but I do not display it anywhere yet.
    }

    public partial class startForm : Form
    {
        public startForm()
        {
            //Start function to create the form.
            InitializeComponent();
            SetupInitialState();
        }

        private void SetupInitialState()
        {
            //  Set up the form where the only thing visible is the start button.
            btnStart.ForeColor = Color.Black;
            lblCreateName.Visible = false;
            txtName.Visible = false;
            btnCreatePet.Visible = false;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            // Makes the start but  disabled and pops in the other items.
            btnStart.Enabled = false;
            lblCreateName.Visible = true;
            txtName.Visible = true;
            btnCreatePet.Visible = true;
        }

        private void btnCreatePet_Click(object sender, EventArgs e)
        {   //Error handling for Pet name.  Has to have something in it.
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Please enter a name for your pet.");
                return;
            }

            //Calls petForm and hides the starting form.
            var petForm = new petForm(txtName.Text);
            petForm.Show();
            this.Hide();
        }
    }

    public partial class petForm : Form
    {   
        //Sets the variable _pet as only able to be assigned from the class if I understood that correctly.
        private readonly VirtualPet _pet;
        // Creates a timer to periodicly adjust variables.
        private Timer _passiveDecayTimer;

        public petForm(string petName)
        {
            //Creates the form object for the petForm.
            InitializeComponent();
            //Assigns the value from the class.
            _pet = new VirtualPet(petName, 0);
            //Calls these functions.
            SetupForm();
            InitializeTimer();
        }

        private void SetupForm()
        {
            // sets up the form.  Creates the little ASCII art and sets the text for the form.  I am not real happy with it but it works for now.
            Text = $"{_pet.Name} - Virtual Pet";
            lblArt.Text = @"   /\_/\ " + Environment.NewLine +
                         @"  ( o o ) " + Environment.NewLine +
                         @"   > ^ <";
            //Creates the progress bars and sets the values to the starting values.
            UpdateStatusBars();
        }

        public void InitializeTimer()
        {
            //Sets the timer to run every 5 seconds and calls the function to adjust the values.
            _passiveDecayTimer = new Timer { Interval = 5000 }; // 5 seconds
            _passiveDecayTimer.Tick += (s, e) =>
            {
                // Decrease hunger, happiness, and energy over time
                _pet.Hunger = Math.Min(100, _pet.Hunger + 5);
                _pet.Happiness = Math.Max(0, _pet.Happiness - 5);
                _pet.Energy = Math.Max(0, _pet.Energy - 3);
                UpdateStatusBars();
            };
            // Start the timer.  If I read right the passive decay timer will run in the background and not block the UI.
            _passiveDecayTimer.Start();
        }

        public void UpdateStatusBars()
        {
            // Updates the progress bars with the values from the class.
            pbHunger.Value = _pet.Hunger;
            pbHappiness.Value = _pet.Happiness;
            pbEnergy.Value = _pet.Energy;

            // Tried again to change the colors.  I knew it did not work that way but I did it anyway...  And of course it did not work.
            //pbHunger.ForeColor = _pet.Hunger > 75 ? Color.Red : Color.LimeGreen;
            //pbHappiness.ForeColor = _pet.Happiness < 25 ? Color.Red : Color.Gold;
            //pbEnergy.ForeColor = _pet.Energy < 20 ? Color.Red : Color.DodgerBlue;
        }

       

        private void petForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // When the form is closing, stop the timer and exit the application.
            _passiveDecayTimer?.Stop();
            Application.Exit();
        }
    }
}