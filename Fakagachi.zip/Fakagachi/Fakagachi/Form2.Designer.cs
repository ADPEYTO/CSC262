﻿namespace Fakagachi
{
    partial class petForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblArt = new System.Windows.Forms.Label();
            this.pbHappiness = new System.Windows.Forms.ProgressBar();
            this.pbEnergy = new System.Windows.Forms.ProgressBar();
            this.pbHunger = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnFeed = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblArt
            // 
            this.lblArt.AutoSize = true;
            this.lblArt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArt.Location = new System.Drawing.Point(133, 45);
            this.lblArt.Name = "lblArt";
            this.lblArt.Size = new System.Drawing.Size(70, 25);
            this.lblArt.TabIndex = 0;
            this.lblArt.Text = "label1";
            // 
            // pbHappiness
            // 
            this.pbHappiness.Location = new System.Drawing.Point(115, 187);
            this.pbHappiness.Name = "pbHappiness";
            this.pbHappiness.Size = new System.Drawing.Size(100, 20);
            this.pbHappiness.TabIndex = 1;
            // 
            // pbEnergy
            // 
            this.pbEnergy.Location = new System.Drawing.Point(115, 217);
            this.pbEnergy.Name = "pbEnergy";
            this.pbEnergy.Size = new System.Drawing.Size(100, 20);
            this.pbEnergy.TabIndex = 2;
            // 
            // pbHunger
            // 
            this.pbHunger.Location = new System.Drawing.Point(115, 247);
            this.pbHunger.Name = "pbHunger";
            this.pbHunger.Size = new System.Drawing.Size(100, 20);
            this.pbHunger.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 193);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Happiness";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 223);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Energy";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 253);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Hunger";
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(32, 290);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(87, 35);
            this.btnPlay.TabIndex = 7;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnFeed
            // 
            this.btnFeed.Location = new System.Drawing.Point(138, 290);
            this.btnFeed.Name = "btnFeed";
            this.btnFeed.Size = new System.Drawing.Size(87, 35);
            this.btnFeed.TabIndex = 8;
            this.btnFeed.Text = "Feed";
            this.btnFeed.UseVisualStyleBackColor = true;
            this.btnFeed.Click += new System.EventHandler(this.btnFeed_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(248, 290);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(87, 35);
            this.button3.TabIndex = 9;
            this.button3.Text = "Sleep";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.btnSleep_Click);
            // 
            // petForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 366);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnFeed);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbHunger);
            this.Controls.Add(this.pbEnergy);
            this.Controls.Add(this.pbHappiness);
            this.Controls.Add(this.lblArt);
            this.Name = "petForm";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblArt;
        private System.Windows.Forms.ProgressBar pbHappiness;
        private System.Windows.Forms.ProgressBar pbEnergy;
        private System.Windows.Forms.ProgressBar pbHunger;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnFeed;
        private System.Windows.Forms.Button button3;
    }
}